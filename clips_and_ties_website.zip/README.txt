CLIPS & TIES WEBSITE
1. Open index.html in a browser to preview.
2. Replace WHATSAPP_NUMBER in index.html with your WhatsApp Business number, including country code.
3. Replace each product image field with your product image filename/path.
4. Upload index.html and image files to your GitHub repository.
5. For real online payments, connect a payment provider such as Razorpay/UPI after the basic catalog is live.
